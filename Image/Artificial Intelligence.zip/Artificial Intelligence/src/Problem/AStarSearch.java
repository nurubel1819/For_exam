package Problem;

import java.util.*;

class Node {
    int x, y; // Coordinates of the node
    int f, g, h; // Values used in A* algorithm
    Node parent; // Parent node

    Node(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Calculate the Manhattan distance to the goal node
    int calculateH(Node goal) {
        return Math.abs(this.x - goal.x) + Math.abs(this.y - goal.y);
    }
}

public class AStarSearch {
    static int[][] grid = {
            {0, 0, 0, 0, 0},
            {0, 0, 1, 1, 0},
            {0, 0, 0, 0, 0},
            {0, 1, 1, 0, 0},
            {0, 0, 0, 0, 0}
    };
    static int[][] directions = {
            {-1, 0}, {1, 0}, {0, -1}, {0, 1}
    };

    static boolean isValid(int x, int y) {
        return x >= 0 && x < grid.length && y >= 0 && y < grid[0].length && grid[x][y] == 0;
    }

    static List<Node> findNeighbors(Node current) {
        List<Node> neighbors = new ArrayList<>();
        for (int[] dir : directions) {
            int newX = current.x + dir[0];
            int newY = current.y + dir[1];
            if (isValid(newX, newY)) {
                neighbors.add(new Node(newX, newY));
            }
        }
        return neighbors;
    }

    static int calculateG(Node current, Node neighbor) {
        // Assuming a cost of 1 to move to a neighbor
        return current.g + 1;
    }

    static void aStarSearch(Node start, Node goal) {
        PriorityQueue<Node> openSet = new PriorityQueue<>(Comparator.comparingInt(node -> node.f));
        Set<Node> closedSet = new HashSet<>();

        start.g = 0;
        start.h = start.calculateH(goal);
        start.f = start.g + start.h;

        openSet.add(start);

        while (!openSet.isEmpty()) {
            Node current = openSet.poll();

            if (current.x == goal.x && current.y == goal.y) {
                // Path found, reconstruct and print the path
                List<Node> path = new ArrayList<>();
                while (current != null) {
                    path.add(current);
                    current = current.parent;
                }
                Collections.reverse(path);
                for (Node node : path) {
                    System.out.println("(" + node.x + ", " + node.y + ")");
                }
                return;
            }

            closedSet.add(current);

            for (Node neighbor : findNeighbors(current)) {
                if (closedSet.contains(neighbor)) {
                    continue;
                }

                int tentativeGScore = calculateG(current, neighbor);

                if (!openSet.contains(neighbor) || tentativeGScore < neighbor.g) {
                    neighbor.parent = current;
                    neighbor.g = tentativeGScore;
                    neighbor.h = neighbor.calculateH(goal);
                    neighbor.f = neighbor.g + neighbor.h;
                    if (!openSet.contains(neighbor)) {
                        openSet.add(neighbor);
                    }
                }
            }
        }
        // No path found
        System.out.println("No path found.");
    }

    public static void main(String[] args) {
        Node start = new Node(0, 0);
        Node goal = new Node(4, 4);
        aStarSearch(start, goal);
    }
}
