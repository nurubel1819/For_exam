package inventory_system;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class main {
    private JPanel panel1;
    private JPanel input_panel;
    private JPanel table_panel;
    private JButton btn_next;

    public main() {
        btn_next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //
            }
        });
    }


    public static void main(String[] args) {
        inventory ob = new inventory();
    }
}
